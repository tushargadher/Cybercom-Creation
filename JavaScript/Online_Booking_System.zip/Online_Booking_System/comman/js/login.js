document.getElementById("RegisterNowButton").addEventListener("click", () => {
  window.location.href = "http://127.0.0.1:5500/comman/html/register.html";
});

let loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
// const userTypeSelect = document.getElementById("userType");
const LOCALSTORAGE = {
  userList: "userList",
};
const SESSIONSTORAGE = {
  loggedUser: "loggedUser",
};

//form validation function
const formValidation = () => {
  let email = emailInput.value.trim();
  let password = passwordInput.value;

  let errors = false;

  document.getElementById("email_error").textContent = "";
  document.getElementById("password_error").textContent = "";

  if (email === "") {
    document.getElementById("email_error").textContent = "Email is required";
    errors = true;
  } else if (!validateEmail(email)) {
    document.getElementById("email_error").textContent = "Invalid email format";
    errors = true;
  }

  if (password === "") {
    document.getElementById("password_error").textContent =
      "Password is required";
    errors = true;
  }
  
  function validateEmail(email) {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
  }
  return errors;
};

loginForm.addEventListener("submit", (e) => {
  e.preventDefault();
  let inputEmail = emailInput.value.trim();
  let inputPassword = passwordInput.value;
  let fromValidate = formValidation();
  console.log(fromValidate);
  if (!fromValidate) {
    let userList =
      JSON.parse(localStorage.getItem(LOCALSTORAGE.userList)) || [];

    const filterUser = userList.filter((user) => user.email === inputEmail);
    console.log(filterUser);
    if (filterUser.length) {
      const { id, email, password, userType, name } = filterUser[0];
      if (inputEmail === email && inputPassword === password) {
        const loggedUser = {
          id: id,
          name: name,
          email: email.toLowerCase(), //lower
          userType: userType,
        };
        sessionStorage.setItem(
          SESSIONSTORAGE.loggedUser,
          JSON.stringify(loggedUser)
        );
        if (userType === "patient") {
          alert("Logged in as Patient");
          window.location.href =
            "http://127.0.0.1:5500/patient/html/dashboard.html";
        } else {
          alert("Logged in as Doctor");
          window.location.href =
            "http://127.0.0.1:5500/docter/html/dashboard.html";
        }
      }
    } else {
      alert("User Not Found");
    }
  }
});
